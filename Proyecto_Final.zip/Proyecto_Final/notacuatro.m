function [frec1,frec2,frec3,frec4] = notacuatro(No)
if No == 32
    frec1 = 493;
    frec2 = 440;
    frec3 = 392;
    frec4 = 440;
elseif No == 33
    frec1 = 587;
    frec2 = 523;
    frec3 = 493;
    frec4 = 523;
elseif No == 34
    frec1 = 689;
    frec2 = 659;
    frec3 = 587;
    frec4 = 659;
elseif No == 35
    frec1 = 987;
    frec2 = 880;
    frec3 = 783;
    frec4 = 880;
end