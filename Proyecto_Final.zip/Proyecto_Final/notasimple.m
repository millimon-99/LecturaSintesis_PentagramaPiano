function frec = notasimple(No)
if No == 1
    frec = 440;
elseif No == 2
    frec = 493;
elseif No == 3
    frec = 523;
elseif No == 4
    frec = 349;
elseif No == 5
    frec = 392;
elseif No == 6
    frec = 261;
elseif No == 7
    frec = 293;
elseif No == 8
    frec = 698;
elseif No == 9
    frec = 880;
elseif No == 10
    frec = 1046;
elseif No == 11
    frec = 987;
elseif No == 12
    frec = 783;
elseif No == 13
    frec = 659;
elseif No == 14
    frec = 329;
elseif No == 15
    frec = 587;
elseif No == 16
    frec = 261;
elseif No == 17
    frec = 698;
elseif No == 18
    frec = 329;
elseif No == 19
    frec = 783;
elseif No == 20
    frec = 1046;
elseif No == 21
    frec = 493;
end